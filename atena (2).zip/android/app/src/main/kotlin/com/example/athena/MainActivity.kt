package com.example.athena

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
